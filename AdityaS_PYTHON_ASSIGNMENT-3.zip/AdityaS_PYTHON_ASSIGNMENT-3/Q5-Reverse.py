#sentence = "Hello, how are you?".
# Write a dictionary comprehension to map words to their reverse in a sentence.
# The output should be - {'Hello,': ',olleH', 'how': 'woh', 'are': 'era', 'you?': '?uoy'}
str = "hello, how are you?"
splittedwords = str.split()
rev_dict = {word : word[::-1] for word in splittedwords}
print(rev_dict)