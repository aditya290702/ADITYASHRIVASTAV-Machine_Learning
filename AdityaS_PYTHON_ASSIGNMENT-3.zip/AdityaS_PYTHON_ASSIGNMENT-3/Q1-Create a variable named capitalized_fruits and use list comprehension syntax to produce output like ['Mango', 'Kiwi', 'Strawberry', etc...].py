def upper():
    fruits = ['mango', 'kiwi', 'strawberry', 'guava', 'pineapple', 'mandarin orange']
    fruits_capital = []
    s = len(fruits)
    n = 0
    for ele in fruits:
        a = ele
        new = a[0].upper() + a[1:]
        fruits_capital.append(new)

    print(fruits_capital)


def main():
    x = upper()
    return (x)

if __name__=="__main__":
	main()
