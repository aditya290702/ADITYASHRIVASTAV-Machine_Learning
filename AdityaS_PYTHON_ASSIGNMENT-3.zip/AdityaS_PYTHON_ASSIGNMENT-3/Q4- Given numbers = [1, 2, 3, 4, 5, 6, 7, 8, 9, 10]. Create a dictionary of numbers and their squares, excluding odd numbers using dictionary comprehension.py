#Given numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].
#Create a dictionary of numbers and their squares, excluding odd numbers using dictionary comprehension

number_list = []
for number in range(1, 11):
    d1 = {}
    if(number%2==0):
        square = number*number
        d1 = {number : square}
        print(d1)

