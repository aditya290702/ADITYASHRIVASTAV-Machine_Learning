def vowel():
    fruits = ['mango', 'kiwi', 'strawberry', 'guava', 'pineapple', 'mandarin orange']
    two_vowels = [ele in fruits if(1 for letter in fruit if letter in 'aeiouAEIOU') == 2]
    print(two_vowels)
