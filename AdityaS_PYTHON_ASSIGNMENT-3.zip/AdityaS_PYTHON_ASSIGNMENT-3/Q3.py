#Given org1 = ["ACGTTTCA", "AGGCCTTA", "AAAACCTG"]
#org2 = ["AGCTTTGA", "GCCGGAAT", "GCTACTGA"]
#find all similar pairs of genome sequences
#(one sequence from org1, one from org2) using list
#comprehension. “Similar” means: similarity(seq1, seq2) > threshold

def orgmatch():
    org1 = ["ACGTTTCA", "AGGCCTTA", "AAAACCTG"]
    org2 = ["AGCTTTGA", "GCCGGAAT", "GCTACTGA"]
    try = "A":
    my = {"A" : "T","C" : "G"}
    print(my)
    #newlist = (list(zip(org1,org2)))
   # print(newlist)

result = orgmatch()
print(result)
