def letssortitout():
    a = [-77,-433,4,5,6,7,2,1]

    Sorted = sorted(a, key=lambda x: x)
    print(Sorted)

def main():
    x = letssortitout()
    print(x)

if __name__=="__main__":
	main()

