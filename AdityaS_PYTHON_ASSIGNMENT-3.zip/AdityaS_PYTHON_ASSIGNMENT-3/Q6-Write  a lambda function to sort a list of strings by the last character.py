def letssortitout():
    a = "mango kiwi strawberry guava pineapple mandarin orange"
    splitted = a.split()
    Sorted = sorted(splitted, key=lambda x: x[-1])
    print(Sorted)

def main():
    x = letssortitout()
    print(x)

if __name__=="__main__":
	main()

