def orgmatch():
    org1 = ["ACGTTTCA", "AGGCCTTA", "AAAACCTG"]
    org2 = ["AGCTTTGA", "GCCGGAAT", "GCTACTGA"]
    newlist = (list(zip(org1,org2)))
    print(newlist)

result = orgmatch()
print(result)
