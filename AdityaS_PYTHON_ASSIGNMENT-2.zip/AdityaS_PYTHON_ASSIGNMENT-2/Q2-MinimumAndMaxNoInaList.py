def findminandmax(a):
    b = len(a)
    i = 0
    j= i+1


    for i in range(0, b):
       # for j in range(1, len(a)):
        if a[j]>a[i]:
            return (a[j])


def main():
     a = [0, 1, 3, 2]
     print (x)

if __name__=="__main__":
    main()