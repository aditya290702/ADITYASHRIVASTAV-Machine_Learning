#Take a DNA sequence and determine
#whether or not it contains any ambiguous
#bases – i.e. any bases that are not A, T, G or C.
#If there is a non ambiguous base, print the non ambiguous base

dna = "ATCGCGYAATTCAC"


import re

sequence =  "ATCGCGYAATTCAC"
pattern = "[^ATCG]"
result = re.search(pattern, sequence)

if result:
    print("AMBIGUOUS",result.group())
else:
    print("NON AMBIGUOUS")
