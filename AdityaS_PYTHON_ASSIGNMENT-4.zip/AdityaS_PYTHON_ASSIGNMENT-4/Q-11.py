import re

sequence = "ACTGCATTATATCGTACGAAATTATACGCGCG"
pattern = '[AT]'
matches = re.findall(pattern, sequence)
list = []
list.append(matches)
print(list)

