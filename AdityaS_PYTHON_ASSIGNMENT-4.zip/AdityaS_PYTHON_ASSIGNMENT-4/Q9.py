#Write a regular expression to extract
#the genus name and species name into
#separate variables.
#For example, if scientific_name = "Homo sapiens", the output
#should be genus is Homo, species is sapiens.
#Test your program with another example of scientific_name = “Drosophila melanogaster”.


import re

scientific_name = input()
split = scientific_name.split(" ")
genus = split[0]
species = split[1]
print("Genus is",genus,"Species is",species)