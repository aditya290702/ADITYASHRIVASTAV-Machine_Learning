import pandas as pd

readjson = pd.read_json('jsonsample.json')
print(readjson)