#Take a DNA sequence and determine whether or
#not it contains any ambiguous bases – i.e. any bases that are
#not A, T, G or C. If there are ambiguous bases, print all ambiguous bases and their positions.
#dna = "CGATNCGGAACGATC"


import re

sequence = "CGATNCGGNAACGATC"
pattern = r"[^ATCG]"
result = re.findall(pattern, sequence)

if result:
    ambilist = []
    ambi = ambilist.append(result)
    print("AMBIGUOUS",ambilist)
else:
    print("NON AMBIGUOUS")
