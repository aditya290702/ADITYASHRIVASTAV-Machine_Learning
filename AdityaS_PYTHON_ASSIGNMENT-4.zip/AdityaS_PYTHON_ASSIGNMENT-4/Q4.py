
#Test if a DNA sequence contains an EcoRI restriction site using regular expressions.
#dna = "ATCGCGAATTCAC"
#pattern = GAATTC

dna = "ATCGCGAATTCAC"
pattern = "GAATTC"



import re

sequence = "ATCGCGAATTCAC"
result = re.search("GAATTC", sequence)

if result:
    print("The restriction site 'GAATTC' is present at position:", result.start())
else:
    print("The restriction site 'GAATTC' is not present")
