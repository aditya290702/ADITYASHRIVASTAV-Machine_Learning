#Check for the presence of an AvaII recognition site,
#which can have two different sequences: GGACC and GGTCC. Use regular expressions.
#dna = "ATCGCGAATTCAC"
#pattern = GGACC and GGTCC

import re

dna = "ATCGCGAATTCAC"
result = re.search("GGACC" and "GGTCC",dna)

if result:
    print("The restriction sites are present at position:", result.start())
else:
    print("The restriction sites are not present")
