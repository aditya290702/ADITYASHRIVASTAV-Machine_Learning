import re

dna = "ATGATTAAT"
seq = r"A[ATGC]TAAT"

match = re.search(seq, dna)
stra = re.split(seq, dna)
enzyme_site = re.search(r"A[ATGC]T", stra)
enzyme_site_cut = re.split(enzyme_site)
if match :
    print(enzyme_site)
else:
    print("NA")
