#Create a module, CSVProcessor.
#It should contain functions for loading
#CSV data from an external
#file (titanic.csv), calculating total number of columns,
#calculating total number of rows and
#filling missing values in any column with zero.
#Use Pandas read_csv and other Pandas
#and Numpy functions. Import this module into another program and demonstrate invoking these methods.

#def RC():
import pandas as pd
import numpy as np
Titanic = pd.read_excel("titanic.xlsx")
cols = Titanic.count(axis='columns')
count = cols.count()
print("the number of columns is ",count)

rows = Titanic.count(axis='rows')
countrow = rows.count()
print("the number of rows is ",countrow)

#def main():
#        x = RC()
#        print(x)

#if __name__=="__main__":
#    main()