#Check for the presence of a BisI restriction site using
#regular expression character groups: A character
#group is a pair of square brackets with a list of characters inside them.
#dna = "ATCGCGAATTCAC"
#pattern = GCNGC, where N represents any base, i.e. A, T, G, C


import re

dna = "ATCGCGAATTCAC"
pattern = "GC[ATGC]TC"

result = re.findall(pattern,dna)

if result:
    print("The pattern",result,"is present")
else:

    print("The pattern is not present")