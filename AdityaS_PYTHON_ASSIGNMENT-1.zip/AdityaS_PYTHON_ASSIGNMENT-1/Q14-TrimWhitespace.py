def trim():
    a=" aditya"
    b=[a]
    c=a.strip(" ")
    print(c)


def main():
    e=trim()
    print(e)

if __name__=="__main__":
    main()