def power():
    print(5 ** 2)

def main():
    y=power()
    return(y)

if __name__=="__main__":
    main()