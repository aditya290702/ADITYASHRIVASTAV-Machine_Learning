def anagrams(a, b):
    x=[a]
    y=[b]
    print (x.split())
def main():
    a = "aditya"
    b = "dityaa"
    x = anagrams(a, b)
    return (x)

if __name__=="__main__":
    main()
