def replace(w):

    b=w.replace("c","d")
    print(b)

def main():
    w = input()
    x=replace(w)
    return(x)

if __name__=="__main__":
    main()