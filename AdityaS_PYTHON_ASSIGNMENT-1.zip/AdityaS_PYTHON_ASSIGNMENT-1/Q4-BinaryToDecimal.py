def BintoDec(n):

      main()



      #FACING PROBLEM WITH THE SYNTAX