def numsplit(n):
    numstr=str(n)
    for digit in numstr:
        print (digit)
def main():
    n = 555
    b = numsplit(n)
    return (b)

if __name__=="__main__":
    main()
